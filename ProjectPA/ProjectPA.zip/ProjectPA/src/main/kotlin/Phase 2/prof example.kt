package `Phase 2`

import main.DirectoryEntity
import main.Entity


class `prof example` {

    class FUC(
        val codigo: String,
        val nome: String,
        val ects: Double,
        val observacoes: String,

    )

    val f = FUC("M4310", "Programação Avançada", 6.0, "la la...")

    fun translate(obj: Any) {
       print ( obj::class.simpleName )
    }
    fun main(args: Array<String>) {
       translate(f)
    }
}