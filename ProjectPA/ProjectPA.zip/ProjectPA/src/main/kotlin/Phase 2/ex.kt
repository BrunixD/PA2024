package `Phase 2`

import kotlin.reflect.full.declaredMemberProperties
import kotlin.reflect.full.valueParameters

val f = `prof example`.FUC("M4310", "Programação Avançada", 6.0, "la la...")




fun translate(obj: Any) {
    //acede nome propriedade : print ( obj::class.declaredMemberProperties.first().name)
    //println(obj::class.declaredMemberProperties.toString())
    println(obj::class.declaredMemberProperties.first().call(obj))
    print ( obj::class.simpleName?.decapitalize() )
}
fun main(args: Array<String>) {
    translate(f)
}