package `Phase 2`

class Anotations {
    @Target(AnnotationTarget.PROPERTY)
    annotation class XmlElementName(val name: String)

    @Target(AnnotationTarget.PROPERTY)
    annotation class XmlAttribute

    @Target(AnnotationTarget.PROPERTY)
    annotation class XmlExclude


}